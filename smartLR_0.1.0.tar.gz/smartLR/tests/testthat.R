library(testthat)
library(smartLR)

test_check("smartLR")
