library(testthat)
library(smartLR)

test_dir("tests/testthat")


